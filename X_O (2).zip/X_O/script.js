let q = 0;
let dv1 = document.querySelector(".a1");
let dv2 = document.querySelector(".a2");
let dv3 = document.querySelector(".a3");
let dv4 = document.querySelector(".a4");
let dv5 = document.querySelector(".a5");
let dv6 = document.querySelector(".a6");
let dv7 = document.querySelector(".a7");
let dv8 = document.querySelector(".a8");
let dv9 = document.querySelector(".a9");
let body = document.getElementsByTagName("BODY")[0];

function change(event){
  if( event.target.innerHTML !== "X" && event.target.innerHTML !== "O" ){
    if((q % 2) == 0){
      event.target.innerHTML = "X"
      q = q + 1;
    }else{
      event.target.innerHTML = "O"
      q = q + 1;
    }
    event.target.style.fontSize = "100px"
  }
  if(q >= 5){
   logic();
  };
}

dv1.addEventListener("click",change);
dv2.addEventListener("click",change);
dv3.addEventListener("click",change);
dv4.addEventListener("click",change);
dv5.addEventListener("click",change);
dv6.addEventListener("click",change);
dv7.addEventListener("click",change);
dv8.addEventListener("click",change);
dv9.addEventListener("click",change);

function logic(){
  if(((dv1.innerHTML === "X") || (dv1.innerHTML === "O")) && ((dv2.innerHTML === "X")||(dv2.innerHTML === "O")) && ((dv3.innerHTML === "X")||(dv3.innerHTML === "O"))){
    if((dv1.innerHTML  === dv2.innerHTML)  && (dv1.innerHTML  === dv3.innerHTML) ){
      setTimeout(function(){
        alert("Հաղթեց " + dv1.innerHTML+ "-ով խաղացող մասնակիցը");
        location.reload();
      }, 500);
    }
  }

  if(((dv4.innerHTML === "X")||(dv4.innerHTML === "O")) && ((dv5.innerHTML === "X")||(dv5.innerHTML === "O")) && ((dv6.innerHTML === "X")||(dv6.innerHTML === "O"))){
    if((dv4.innerHTML  === dv5.innerHTML)  && (dv4.innerHTML  === dv6.innerHTML)){
      setTimeout(function(){
        alert("Հաղթեց " + dv4.innerHTML+ "-ով խաղացող մասնակիցը");
        location.reload();
      }, 500);
    }
  };

  if(((dv7.innerHTML === "X")||(dv7.innerHTML === "O")) &&((dv8.innerHTML === "X")||(dv8.innerHTML === "O")) && ((dv9.innerHTML === "X")||(dv9.innerHTML === "O"))){
    if((dv7.innerHTML  === dv8.innerHTML)  && (dv7.innerHTML  === dv9.innerHTML)){
      setTimeout(function(){
        alert("Հաղթեց " + dv7.innerHTML+ "-ով խաղացող մասնակիցը");
        location.reload();
      }, 500);
    }
  };

  if(((dv1.innerHTML === "X")||(dv1.innerHTML === "O")) && ((dv4.innerHTML === "X")||(dv4.innerHTML === "O")) && ((dv7.innerHTML === "X")||(dv7.innerHTML === "O"))){
    if((dv1.innerHTML  === dv4.innerHTML)  && (dv1.innerHTML  === dv7.innerHTML)){
      setTimeout(function(){
        alert("Հաղթեց " + dv1.innerHTML+ "-ով խաղացող մասնակիցը");
        location.reload();
      }, 500);
    };
  };

  if(((dv2.innerHTML === "X")||(dv2.innerHTML === "O")) && ((dv5.innerHTML === "X")||(dv5.innerHTML === "O")) && ((dv8.innerHTML === "X")||(dv8.innerHTML === "O"))){
    if((dv2.innerHTML  === dv5.innerHTML)  && (dv2.innerHTML  === dv8.innerHTML)){
      setTimeout(function(){
        alert("Հաղթեց " + dv2.innerHTML+ "-ով խաղացող մասնակիցը");
        location.reload();
      }, 500);
    };
  };

  if(((dv3.innerHTML === "X")||(dv3.innerHTML === "O")) && ((dv6.innerHTML === "X")||(dv6.innerHTML === "O")) && ((dv9.innerHTML === "X")||(dv9.innerHTML === "O"))){
    if((dv3.innerHTML  === dv6.innerHTML)  && (dv3.innerHTML  === dv9.innerHTML)){
      setTimeout(function(){
        alert("Հաղթեց " + dv3.innerHTML+ "-ով խաղացող մասնակիցը");
        location.reload();
      }, 500);
    };
  };

  if(((dv1.innerHTML === "X")||(dv1.innerHTML === "O")) && ((dv5.innerHTML === "X")||(dv5.innerHTML === "O")) && ((dv9.innerHTML === "X")||(dv9.innerHTML === "O"))){
    if((dv1.innerHTML  === dv5.innerHTML)  && (dv1.innerHTML  === dv9.innerHTML)){
      setTimeout(function(){
        alert("Հաղթեց " + dv1.innerHTML+ "-ով խաղացող մասնակիցը");
        location.reload();
      }, 500);
    };
  };

  if(((dv3.innerHTML === "X")||(dv3.innerHTML === "O")) && ((dv5.innerHTML === "X")||(dv5.innerHTML === "O")) && ((dv7.innerHTML === "X")||(dv7.innerHTML === "O"))){
    if((dv3.innerHTML  === dv5.innerHTML)  && (dv3.innerHTML  === dv7.innerHTML)){
      setTimeout(function(){
        alert("Հաղթեց " + dv3.innerHTML+ "-ով խաղացող մասնակիցը");
        location.reload();
      }, 500);
    };
  };

  if(q === 9){
    setTimeout(function(){
      location.reload();
    },1000);
  }
}
